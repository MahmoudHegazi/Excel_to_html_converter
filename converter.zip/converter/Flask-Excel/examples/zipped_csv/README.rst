Serving a Zip file of data within a flask app
=============================================================

This application shows how to make your data as a zipped csv file
